# SHH Club Website

Private club site.

## Admin Password
**shhclub123**

## Getting a Simple URL (shhclub)
1. Download the site (it saves as `index.html`).
2. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
3. Drag the `index.html` file onto the page.
4. After it deploys, click **Site settings** → **Change site name**.
5. Set the name to **shhclub** (or `shhclub1`, `shhclub2026`, etc. if the name is taken).
6. Your link will be: **https://shhclub.netlify.app**

Share that link. The site is not indexed by search engines.

## Updating Content
Edit in Admin mode → Save → Download Site → re-upload the new `index.html` to replace the old one on Netlify.

## Features
- Editable content, logos, announcements sidebar, rich text, add/remove tabs, email composer, mobile-friendly.
